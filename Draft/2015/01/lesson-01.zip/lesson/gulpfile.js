'use strict';
 
var gulp = require('gulp');
var sass = require('gulp-sass');
var csscomb = require('gulp-csscomb');
var autoprefixer = require('gulp-autoprefixer');
var plumber = require('gulp-plumber');
 
gulp.task('sass', function () {
  gulp.src('./develop/sass/**/*.sass')
    .pipe(plumber())
    .pipe(sass().on('error', sass.logError))
    .pipe(csscomb())
    .pipe(autoprefixer({
      browsers:['safari 5', 'ie 8', 'ie 9', 'ie 10', 'ie 11', 'opera 12.1', 'firefox 14', 'ios 6', 'android 2.1'],
      cascade: false
    }))
    .pipe(gulp.dest('./html/css'));
});
 
gulp.task('sass:watch', function () {
  gulp.watch('./develop/sass/**/*.sass', ['sass']);
});